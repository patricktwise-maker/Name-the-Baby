# Name the Baby: Launch Checklist

## Product
- [x] One-page responsive site
- [x] 1,500-name discovery catalog
- [x] Rich curated profile layer
- [x] SSA popularity intelligence
- [x] Taste DNA
- [x] Name Creation Lab
- [x] Saved shortlist and Name Battle
- [x] Shareable family ballots
- [x] Live-voting backend wiring
- [x] Sponsor inquiry backend wiring
- [x] Privacy-light product analytics wiring

## Before the public URL goes live
- [ ] Create Supabase project
- [ ] Run `supabase-schema.sql`
- [ ] Test connection from Launch Status
- [ ] Put Project URL + publishable key into production `NTB_BACKEND`
- [ ] Choose and register domain
- [ ] Upload `index.html` to HTTPS hosting
- [ ] Test generator on phone and desktop
- [ ] Test family ballot from a second device/network
- [ ] Submit a test sponsor inquiry and confirm it appears in Supabase
- [ ] Review analytics event rows
- [ ] Replace Privacy/Terms previews with final production language
- [ ] Complete editorial review of high-traffic extended-catalog names
- [ ] Add final sponsor price sheet / campaign policy

## Launch-day checks
- [ ] Page loads on HTTPS
- [ ] No console errors
- [ ] Share link opens the same one-page site
- [ ] Live vote count increments across devices
- [ ] Sponsor inquiry reaches private table
- [ ] Analytics page_view event appears
- [ ] Social preview title/description look correct
