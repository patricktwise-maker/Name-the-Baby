# Name the Baby V10: Launch Backend Setup

The visitor-facing site remains one page: `index.html`.

## 1. Create a Supabase project
Create a Supabase project and open the SQL Editor.

## 2. Install the launch backend
Paste and run `supabase-schema.sql`.

It creates locked tables for:
- live family ballots
- ballot options and votes
- sponsor inquiries
- privacy-light product events

Browser roles receive no direct table access. The page can call only the narrow RPC functions explicitly granted to `anon` / `authenticated`.

## 3. Get the browser-safe connection values
From Supabase, copy:
- Project URL
- Publishable key (`sb_publishable_...`)

Never place a secret key or service-role key in the HTML.

## 4. Test without editing code
Open `index.html`, scroll to the footer, choose **Launch Status**, paste the Project URL and publishable key, then click **Save & Test**.

That stores the public configuration only in that browser. It is useful for testing.

## 5. Production configuration
Before publishing, put the same Project URL and publishable key into the `NTB_BACKEND` object in `index.html`, then remove your browser-only test override if desired.

## 6. What turns on after connection
- real cross-device ballot IDs and totals
- one current vote per browser token, with vote changes allowed
- sponsor inquiry delivery into `public.sponsor_inquiries`
- privacy-light product event logging into `public.ntb_events`
- launch-status health test

## 7. What analytics deliberately do NOT send
The V10 event logger omits exact generated names, surnames, family labels, email addresses, and sponsor messages. Shared-ballot content and sponsor contact data are stored only when the visitor intentionally submits those features.

## 8. View sponsor inquiries
Use the Supabase dashboard/table editor as the private inbox, or query as an owner/server role:

```sql
select company, contact_name, email, budget, note, created_at
from public.sponsor_inquiries
order by created_at desc;
```

## 9. Basic analytics examples

```sql
select event_name, count(*)
from public.ntb_events
where created_at >= now() - interval '30 days'
group by event_name
order by count(*) desc;
```

```sql
select date_trunc('day', created_at) as day, count(*) as generations
from public.ntb_events
where event_name = 'name_generated'
group by 1
order by 1;
```
